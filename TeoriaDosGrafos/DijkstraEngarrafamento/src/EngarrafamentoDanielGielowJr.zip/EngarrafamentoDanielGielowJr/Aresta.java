//DANIEL GIELOW JUNIOR
package EngarrafamentoDanielGielowJr;

class Aresta
{
    public final Vertice verticeDestino;
    public final int peso;
    
    public Aresta(Vertice verticeDestino, int peso)    { 
    	this.verticeDestino = verticeDestino; 
    	this.peso = peso; 
    }
}
